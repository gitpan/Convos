(function(w) {
  w.console.log('a');
}(window));
